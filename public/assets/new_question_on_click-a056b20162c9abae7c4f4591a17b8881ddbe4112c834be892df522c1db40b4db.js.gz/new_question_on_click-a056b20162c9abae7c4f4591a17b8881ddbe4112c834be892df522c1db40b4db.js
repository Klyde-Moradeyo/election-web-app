(() => {
  // app/javascript/new_question_on_click.js
  $(document).on("click", "#new_question_on_click", function() {
    $(question_form1).toggle();
  });
})();
//# sourceMappingURL=/assets/new_question_on_click.js-403d0edd31b4e0723dfd03dc5f9a8998b2b083fafd4acd94466f028973974f5e.map
//!
;
